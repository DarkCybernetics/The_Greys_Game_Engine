class Display
{

    public:
        int Texture_Size = 16;
        int Texture_Width = 512;
        int Texture_Height = 512;
        int Texture_UV_x = 0;
        int Texture_UV_y = 0;

    private:
        void load_Texture(Texture_Height,Texture_Size,Texture_Width);
        void load_file();
    protected:


}
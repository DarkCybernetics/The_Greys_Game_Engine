===============================================
DarkCybernetics
Learn Play and Discover Computer Science
----------------------------------------------
Note: Fan Game all copyrights for MIB belong
to offical sources. This project was created
for educational purposes for students in a 
Computer Graphics course using modern APIs.
===============================================
The Grey's Game Engine
Project Title : MIB The Greys
Author: Dion Jackson 1/17/2023
---------------
Graphic Art Style : Cartoon < MIB Animated Series>
-----------------
Description: 3rd person shooter with lightsaber combat and space fighter combat.
Control a MIB agent. J K then fight alien greys and other aliens to defend your sector of the Galaxy.
-------------------------------------------------
Projects description: a crossplatform modern 3D platformer with controller support and online play.
-------------------------------------------------
Engine
~~~~~~~~~~~~~~~
- Lights < point light , directional light>
- Spawners < AI controlled agents to target the player(s)>
- Shadows < all objects>
- Materials < surfaces>
- Transparency< Glass / Water>
- Traffic < NPCs/ Humanoid Agents /Vechicle >
- 3d Models < lowpoly >
- Reflections < materials / surfaces>
- Culling Techniques
- Cross-platform < Windows/Linux/Mac>
- Terriagn < City / Buildings / Roads/ Tree/ Rocks/ Signs>

===============================================
Controls < keyboard > -> Controller maybe later
~~~~~~~~
Mouse Aiming toggleable for controller
Mouse 1 - left swing
Mouse 2 - right swing
Enter - action button/ leave vehicle
Q - left side step 
W- forward/ accelerate
E- left side step 
R- reload 
A- left turn
S- back step
D- right turn
F - throw
T- change weapon mode  1
G-  change weapon mode 2
===================
|    Hotkeys      |
===================
1 - Hands
2 - Feet
3 - Weapon Mode
4 - Energy Mode
5 - Fields
6 - Flips
7 - Speed 
8 - Scans
9 - N/A
0 - N/A

Spacebar - jump/ double tap to flip
Enter - action button
Escape - exit
Tab - log of game status and objectives

===============================================
Gamepay
~~~~~~~~
Jediacademy like combat

===============================================
Menu Modes
~~~~~~~~
Play
Multiplayer Online
Load Game
Options
Credits
Exit

===============================================
Characters
~~~~~~~~ 
Humanoids
Agents
Civilians
MIB NPCs < Twins / Worms / Z (ed) >
Civil Servants< Police/ Fire Fighters / EMT / etc/ >
====================Alien Races ===================

A

    Adorian
    Adorian
    Alcidian
    Alcidian
    Archanan
    Arquilian
    Arquilian
    Arquilian Galaxy
    Arquilian Galaxy

B

    Ballchinian
    Ballchinian
    Baltian
    Baltian
    Baltian First Contact
    Baltian First Contact
    Barooga
    Barooga
    Bartoquian
    Bartoquian
    Beetle Mouse
    Blastula
    Blastula
    Boglodite
    Boglodite
    Bogus
    Bogus
    Bovolot
    Bovolot
    Brain
    Brain
    Braxian
    Bug
    Bug
    Byvoid
    Byvoid

C

    Cephalapoid
    Cephalapoid
    Charnock
    Charnock
    Chloropod
    Chloropod
    Ciraldian
    Ciraldian

D

    Darkon
    Darkon
    Doldunian
    Doldunian

E

    Emiculus Cephaloid
    Emiculus Cephaloid
    Empirian
    Empirian

F

    Fmeks
    Fmeks
    Frazians
    Frazians
    Frostifarians
    Frostifarians

G

    Gorgonite
    Gorgonite
    Gravlax
    Gravlax

H

    Huntak
    Huntak
    Hyperian
    Hyperian

I

    Inanimate
    Inanimate
    Ixion
    Ixion

J

    Jababians
    Jababians

K

    Kelortian
    Kelortian
    Kylothian
    Kylothian

M

    Metaphite
    Metaphite

N

    Nakkadan
    Nakkadan
    Nexvo
    Nexvo

P

    Parlaxian
    Pinosapian
    Pinosapian
    Pzim
    Pzim

R

    Rebels
    Rebels
    Remoolian
    Remoolian
    Rosean
    Rosean

S

    Samurian
    Sintillian
    Sintillian
    Skraaldian
    Skraaldian
    Spikey Bulba
    Spikey Bulba
    Squid
    Squid
    Stellairian
    Stellairian
    Symbiote
    Symbiote

T

    Taranbee
    Taranbee
    Tarkan
    Tarkan
    Terminias
    Terminias
    Terrantian
    Terrantian
    The Hive
    The Hive
    Tresfin
    Tresfin
    Tricainasloph
    Tricainasloph
    Tunstons
    Tunstons
    Twins
    Twins

U

    Uixquilucan
    Uixquilucan

V

    Vexron
    Vexron

W

    Wano
    Wano
    Worm
    Worm

Z

    Z-Ron
    Z-Ron
    Zadoranian
    Zadoranian
    Zangarian
    Zangarian
    Zarthan
    Zarthan
    Zombarian
    Zombarian


===============================================
www.DarkCybernetics.com
All rights reserved 2023.


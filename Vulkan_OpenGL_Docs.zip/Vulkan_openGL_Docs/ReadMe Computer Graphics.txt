Computer Graphics in Vulkan and Modern OpenGL
============================================================
Description: In the following Computer Graphics course students will be introduced to modern graphics and rendering
Techniques using 2 application programming interfaces called Vulkan and OpenGL. There will be rendering concepts and
issues familiar with anyone who has taken High School level mathematics courses.

Learning Vulkan and Modern OpenGL
--------------
0 Vulkan or OpenGL Base Project
1 Vulkan Vertex Buffer
2 GPUs and Other Graphic Devices
3 Vulkan Uniform Buffers
4 Vulkan Texture Mapping
5 Vulkan Depth Buffers
6 Loading Models for Vulkan or Modern OpenGL
7 Vulkan Generating Mipmaps
8 Vulkan Multisampling
9 Vulkan Compute Shaders
10 Vulkan Rendering Pipeline
11 Vulkan Command Buffers
12 Vulkan Texturing Models
13 Vulkan Descriptors
14 Vulkan Swap Chain
15 Vulkan Staging 
16 Vulkan Synchronization
17 Animation
18 Real time Rendering Techniques
19 Transformations in Vulkan or OpenGL
20 Coordinate Systems in Vulkan or OpenGL
21 Shader Languages
22 Visible Surface Detection Algorithms
23 Fractals and Melbrats
24 Viewing and Clipping Algorithms
25 Perspectives
26 Skybox
27 Lighting Techniques
28 Shaders
29 Curve Techniques
30 Shadows
31 Filtering and Diltering
32 Anti-aliasing Techniques
33 Moving the Camera in Vulkan and Modern OpenGL
34 Working with Polygons

Computer Graphics Concepts
========================================


